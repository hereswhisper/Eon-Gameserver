#pragma once

// Dumped with Dumper-7!

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xD80 - 0xD80)
// BlueprintGeneratedClass Athena_PlayerCameraMode_HeldObject.Athena_PlayerCameraMode_HeldObject_C
class UAthena_PlayerCameraMode_HeldObject_C : public UAthena_PlayerCameraModeRanged_C
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = UObject::FindClassFast("Athena_PlayerCameraMode_HeldObject_C");
		return Clss;
	}

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
