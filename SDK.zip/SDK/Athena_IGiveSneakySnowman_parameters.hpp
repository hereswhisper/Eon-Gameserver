#pragma once

// Dumped with Dumper-7!

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x4 (0x4 - 0x0)
// Function Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C.GetMaterialInt
struct IAthena_IGiveSneakySnowman_C_GetMaterialInt_Params
{
public:
	int32                                        MatInt;                                            // 0x0(0x4)(Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// 0x0 (0x0 - 0x0)
// Function Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C.SpawnParticles
struct IAthena_IGiveSneakySnowman_C_SpawnParticles_Params
{
public:
};

// 0x30 (0x30 - 0x0)
// Function Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C.GetNewSnowmanTransform
struct IAthena_IGiveSneakySnowman_C_GetNewSnowmanTransform_Params
{
public:
	struct FTransform                            Transform;                                         // 0x0(0x30)(Parm, OutParm, IsPlainOldData, NoDestructor)
};

// 0x0 (0x0 - 0x0)
// Function Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C.OnTookSneakySnowman
struct IAthena_IGiveSneakySnowman_C_OnTookSneakySnowman_Params
{
public:
};

// 0x0 (0x0 - 0x0)
// Function Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C.OnStartedJumpingIn
struct IAthena_IGiveSneakySnowman_C_OnStartedJumpingIn_Params
{
public:
};

// 0x8 (0x8 - 0x0)
// Function Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C.MovePlayer
struct IAthena_IGiveSneakySnowman_C_MovePlayer_Params
{
public:
	class AActor*                                Player;                                            // 0x0(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// 0x0 (0x0 - 0x0)
// Function Athena_IGiveSneakySnowman.Athena_IGiveSneakySnowman_C.OnGaveSneakySnowman
struct IAthena_IGiveSneakySnowman_C_OnGaveSneakySnowman_Params
{
public:
};

}
}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
