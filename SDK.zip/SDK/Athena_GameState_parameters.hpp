#pragma once

// Dumped with Dumper-7!

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x0 - 0x0)
// Function Athena_GameState.Athena_GameState_C.Timeline_0__FinishedFunc
struct AAthena_GameState_C_Timeline_0__FinishedFunc_Params
{
public:
};

// 0x0 (0x0 - 0x0)
// Function Athena_GameState.Athena_GameState_C.Timeline_0__UpdateFunc
struct AAthena_GameState_C_Timeline_0__UpdateFunc_Params
{
public:
};

// 0x0 (0x0 - 0x0)
// Function Athena_GameState.Athena_GameState_C.OnWinnerAnnounced
struct AAthena_GameState_C_OnWinnerAnnounced_Params
{
public:
};

// 0x7 (0x7 - 0x0)
// Function Athena_GameState.Athena_GameState_C.ExecuteUbergraph_Athena_GameState
struct AAthena_GameState_C_ExecuteUbergraph_Athena_GameState_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         Temp_bool_Has_Been_Initd_Variable;                 // 0x4(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                         Temp_bool_IsClosed_Variable;                       // 0x5(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                         CallFunc_CanUseSlowMotionOnVictory_ReturnValue;    // 0x6(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
};

}
}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
