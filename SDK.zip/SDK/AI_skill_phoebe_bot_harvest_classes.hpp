#pragma once

// Dumped with Dumper-7!

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xA8 - 0xA8)
// BlueprintGeneratedClass AI_skill_phoebe_bot_harvest.AI_skill_phoebe_bot_harvest_C
class UAI_skill_phoebe_bot_harvest_C : public UFortAthenaAIBotHarvestSkillSet
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = UObject::FindClassFast("AI_skill_phoebe_bot_harvest_C");
		return Clss;
	}

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
